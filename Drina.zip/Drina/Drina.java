package Drina;

import java.util.Comparator;
import java.util.SortedSet;

public class Drina
{
    private final Offer[] offers;
    private long[] array;
    private long[] maxComb;

    public Drina(SortedSet<Offer> offers)
    {
        this.offers = offers.toArray(new Offer[offers.size()]);
        this.array = null;
    }

    public void buildArray()
    {
        array = new long[offers.length + 1];

        for(int i = 0; i < array.length; i++)
            array[i] = 0;
    }

    public long solveDP()
    {
        buildArray();
        for(int i = 1; i <= offers.length; i++)
        {
            long max = getOffer(i).price;
            for(int k = 1; compatible(k, i);  k++)
            {   
                long r = 0;
                if(k == 0 || array[k] > array[k-1])
                    r = getOffer(i).price + array[k];
                else
                    r = getOffer(i).price;
                max = Math.max(max, r);
            }
            array[i] = Math.max( max, array[i-1]);
        }
        return array[offers.length];
    }

    public long solveR()
    {
        return solveRS(offers.length);
    }

    private Offer getOffer(int i)
    {
        return offers[i-1];
    }

    public long solveRS(int i)
    {
        if (i == 0)
            return 0;
        long max = getOffer(i).price;
        for(int k = 1; compatible(k, i); k++)
        {
            long r = 0;
            if(k == 0 || solveRS(k) > solveRS(k-1))
                r = getOffer(i).price + solveRS(k);
            else
                r = getOffer(i).price;
            max = Math.max(max, r);
        }
        return max;
    }

    private boolean compatible(int i, int j)
    {
        return i == 0 || (getOffer(i).endTime <= getOffer(j).startingTime);
    }
}

    